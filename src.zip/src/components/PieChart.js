import React from 'react';
import { Pie } from 'react-chartjs-2';
import carData from '../data/taladrod-cars.json';

function PieChart() {
  const brandCounts = carData.reduce((acc, car) => {
    acc[car.brand] = (acc[car.brand] || 0) + 1;
    return acc;
  }, {});

  const data = {
    labels: Object.keys(brandCounts),
    datasets: [
      {
        label: 'Car Distribution by Brand',
        data: Object.values(brandCounts),
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
      },
    ],
  };

  return <Pie data={data} />;
}

export default PieChart;
