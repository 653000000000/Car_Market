import React from 'react';
import carData from '../data/taladrod-cars.json';

function CarTable() {
  const brandModelData = carData.reduce((acc, car) => {
    const { brand, model, price } = car;
    if (!acc[brand]) {
      acc[brand] = { totalValue: 0, models: {} };
    }
    if (!acc[brand].models[model]) {
      acc[brand].models[model] = { count: 0, totalValue: 0 };
    }
    acc[brand].totalValue += price;
    acc[brand].models[model].count += 1;
    acc[brand].models[model].totalValue += price;
    return acc;
  }, {});

  return (
    <table>
      <thead>
        <tr>
          <th>Brand</th>
          <th>Model</th>
          <th>Count</th>
          <th>Total Value (Baht)</th>
        </tr>
      </thead>
      <tbody>
        {Object.keys(brandModelData).map(brand => (
          <React.Fragment key={brand}>
            <tr>
              <td>{brand}</td>
              <td colSpan="3">Total Value: {brandModelData[brand].totalValue} Baht</td>
            </tr>
            {Object.keys(brandModelData[brand].models).map(model => (
              <tr key={model}>
                <td></td>
                <td>{model}</td>
                <td>{brandModelData[brand].models[model].count}</td>
                <td>{brandModelData[brand].models[model].totalValue} Baht</td>
              </tr>
            ))}
          </React.Fragment>
        ))}
      </tbody>
    </table>
  );
}

export default CarTable;
