import React from 'react';
import CarTable from './CarTable';
import PieChart from './PieChart';
import StackedBarChart from './StackedBarChart';

function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <CarTable />
      <PieChart />
      <StackedBarChart />
    </div>
  );
}

export default Dashboard;
