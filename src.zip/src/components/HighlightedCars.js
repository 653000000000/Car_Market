import React, { useState, useEffect } from 'react';

function HighlightedCars() {
  const [highlightedCars, setHighlightedCars] = useState([]);

  useEffect(() => {
    const storedCars = JSON.parse(localStorage.getItem('highlightedCars')) || [];
    setHighlightedCars(storedCars);
  }, []);

  const removeCar = (carId) => {
    const updatedCars = highlightedCars.filter(car => car.id !== carId);
    setHighlightedCars(updatedCars);
    localStorage.setItem('highlightedCars', JSON.stringify(updatedCars));
  };

  return (
    <div>
      <h1>Highlighted Cars</h1>
      <ul>
        {highlightedCars.map(car => (
          <li key={car.id}>
            {car.name} - {car.price} Baht
            <button onClick={() => removeCar(car.id)}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default HighlightedCars;
