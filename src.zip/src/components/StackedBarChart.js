import React from 'react';
import { Bar } from 'react-chartjs-2';
import carData from '../data/taladrod-cars.json';

function StackedBarChart() {
  const brandModelData = carData.reduce((acc, car) => {
    if (!acc[car.brand]) acc[car.brand] = {};
    acc[car.brand][car.model] = (acc[car.brand][car.model] || 0) + 1;
    return acc;
  }, {});

  const data = {
    labels: Object.keys(brandModelData),
    datasets: Object.keys(brandModelData).flatMap(brand => (
      Object.keys(brandModelData[brand]).map(model => ({
        label: model,
        data: Object.keys(brandModelData).map(b => (b === brand ? brandModelData[brand][model] : 0)),
        backgroundColor: `#${Math.floor(Math.random()*16777215).toString(16)}`,
      }))
    )),
  };

  const options = {
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
      },
    },
  };

  return <Bar data={data} options={options} />;
}

export default StackedBarChart;
